import fs from 'fs';
import axios from 'axios';
import FormData from 'form-data';
import { uploadToQuax } from "../../system/utils.js";

const handler = async (m, { conn, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';

  if (!mime) throw '*رد علي الصوره او الفيديو أو الصوت🔗 لتحويله لرابط*';
  
  const media = await q.download();
  const link = await uploadToQuax(media);
  
  await conn.sendButton(m.chat, {
    imageUrl: link,
    bodyText: "🗃️ نجح رفع الصورة على *(catbox.moe)*\n- ```" + link + "```",
    footerText: "𝑯𝑨𝒀𝑨𝑻𝑶 ┇🩸┇ 𝑩𝑶𝑻",
    buttons: [
      { name: "cta_copy", params: { display_text: "Copy Link", copy_code: link } },
    ],
    mentions: [m.sender],
    newsletter: {
      name: '𝑯𝑨𝒀𝑨𝑻𝑶 ┇🩸┇ 𝑪𝑯𝑨𝑵𝑵𝑬𝑳',
      jid: '120363415135074168@newsletter'
    },
    interactiveConfig: {
      buttons_limits: 10,
      list_title: "𝑯𝑨𝒀𝑨𝑻𝑶 ┇🩸┇ 𝑩𝑶𝑻",
      button_title: "Click Here",
      canonical_url: "https://vxv-profile.vercel.app"
    }
  }, m);
};

handler.usage = ["لرابط"];
handler.category = "tools";
handler.command = ['لرابط', 'image2url'];

export default handler;